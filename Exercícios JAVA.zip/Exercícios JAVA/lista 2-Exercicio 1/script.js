function calcularAumentos() {
    const cotacaoInput = document.getElementById("cotacao");
    const resultadoDiv = document.getElementById("resultado");

    const cotacao = parseFloat(cotacaoInput.value);

    if (isNaN(cotacao) || cotacao <= 0) {
        resultadoDiv.innerHTML = "<p style='color:red;'>Por favor, insira uma cotação válida.</p>";
        return;
    }

    const aumentos = [1, 2, 5, 10];
    let resultadoHTML = "<h2>Resultados:</h2><ul>";

    aumentos.forEach(porcentagem => {
        const valorComAumento = cotacao * (1 + porcentagem / 100);
        resultadoHTML += `<li>${porcentagem}% de aumento: R$ ${valorComAumento.toFixed(2)}</li>`;
    });

    resultadoHTML += "</ul>";
    resultadoDiv.innerHTML = resultadoHTML;
}