function calcularTroco() {
    const valorPago = parseFloat(document.getElementById('valorPago').value) || 0;
    const precoProduto = parseFloat(document.getElementById('precoProduto').value) || 0;
    const resultado = document.getElementById('resultado');

    if (valorPago <= 0 || precoProduto <= 0) {
        resultado.textContent = 'Insira valores maiores que zero.';
        return;
    }

    if (valorPago < precoProduto) {
        resultado.textContent = 'Valor pago insuficiente.';
        return;
    }

    const troco = valorPago - precoProduto;
    resultado.textContent = 'Troco: R$ ' + troco.toFixed(2);
}