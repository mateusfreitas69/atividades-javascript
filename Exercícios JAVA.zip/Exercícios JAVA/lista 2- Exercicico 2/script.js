function calcularIngredientes() {
    const pessoas = document.getElementById('pessoas').value;
    const ovosPorPessoa = 2;
    const queijoPorPessoa = 50; // em gramas

    if (pessoas && pessoas > 0) {
        const totalOvos = pessoas * ovosPorPessoa;
        const totalQueijo = pessoas * queijoPorPessoa;

        document.getElementById('resultado').innerText =
            `${totalOvos} ovos e ${totalQueijo} gramas de queijo serão necessários.`;
    } else {
        document.getElementById('resultado').innerText =
            'Por favor, insira um número válido de pessoas.';
    }
}