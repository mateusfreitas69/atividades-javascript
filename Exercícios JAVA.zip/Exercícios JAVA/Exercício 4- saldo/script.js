function reajustarSaldo() {
    const saldoInput = document.getElementById("saldo");
    const resultado = document.getElementById("resultado");

    const saldo = parseFloat(saldoInput.value);

    if (isNaN(saldo)) {
        resultado.textContent = "Por favor, insira um valor numérico válido.";
        resultado.style.color = "red";
        return;
    }

    const saldoReajustado = saldo * 1.01;
    resultado.textContent = `Saldo com reajuste de 1%: R$ ${saldoReajustado.toFixed(2)}`;
    resultado.style.color = "blue";
}