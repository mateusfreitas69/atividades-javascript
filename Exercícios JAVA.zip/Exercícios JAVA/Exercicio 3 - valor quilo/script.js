function calcularValor() {
    const precoQuilo = parseFloat(document.getElementById("precoQuilo").value);
    const quantidade = parseFloat(document.getElementById("quantidade").value);
    const resultado = document.getElementById("resultado");

    if (isNaN(precoQuilo) || isNaN(quantidade)) {
        resultado.textContent = "Por favor, preencha os campos corretamente.";
        resultado.style.color = "red";
        return;
    }

    const valorFinal = precoQuilo * quantidade;
    resultado.textContent = `Valor final a ser pago: R$ ${valorFinal.toFixed(2)}`;
    resultado.style.color = "green";
}