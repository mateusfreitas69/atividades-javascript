function calcularPedido() {
    var sabor1 = document.getElementById("sabor1").value;
    var sabor2 = document.getElementById("sabor2").value;
    var sabor3 = document.getElementById("sabor3").value;
    var sabor4 = document.getElementById("sabor4").value;
    var refrigerantes = document.getElementById("refrigerantes").value;

    var precoPizza = 12;
    var precoRefrigerante = 7;

    var totalPizza = 4 * precoPizza;
    var totalRefri = refrigerantes * precoRefrigerante;
    var total = totalPizza + totalRefri;

    var resultado = "Sabores escolhidos:<br>";
    resultado += sabor1 + "<br>";
    resultado += sabor2 + "<br>";
    resultado += sabor3 + "<br>";
    resultado += sabor4 + "<br><br>";
    resultado += "Refrigerantes: " + refrigerantes + "<br><br>";
    resultado += "Total a pagar: R$ " + total.toFixed(2).replace(".", ",");

    document.getElementById("resultado").innerHTML = resultado;
}